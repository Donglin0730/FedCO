from .cifar import CIFAR10_truncated, CIFAR100_truncated
from .imgfolder import ImageFolder_custom
