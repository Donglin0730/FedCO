cd data/tiny-imagenet-200
python3 preprocess_tiny_imagenet.py
cd ../../

