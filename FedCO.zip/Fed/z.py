from spire.pdf.common import *
from spire.pdf import *

# 创建一个PdfDocument类的对象
pdf = PdfDocument()

# 清除文档页边距
pdf.PageSettings.Margins.All = 0.0

# 载入需要转换的图片
image = PdfImage.FromFile("C:\\Users\\lyh\\Desktop\\微信图片_20250102104123.png")

# 获取图片的高度和宽度
image_width = image.PhysicalDimension.Width
image_height = image.PhysicalDimension.Height

# 在PDF文档中添加一个与图片相同大小的页面
page = pdf.Pages.Add(SizeF(image_width, image_height))

# 将图片添加到页面上
page.Canvas.DrawImage(image, 0.0, 0.0, image_width, image_height)

# 保存PDF文档
pdf.SaveToFile("C:\\Users\\lyh\\Desktop\\微信图片_20250102104123.png.pdf")
pdf.Close()