# *************************************************************************
# Copyright 2023 ByteDance and/or its affiliates
#
# Copyright 2023 FedDecorr Authors
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
# *************************************************************************


import torch
import torch.nn as nn


class FedDecorrLoss(nn.Module):

    def __init__(self):
        super(FedDecorrLoss, self).__init__()
        self.eps = 1e-8

    def _off_diagonal(self, mat):
        # return a flattened view of the off-diagonal elements of a square matrix
        n, m = mat.shape
        assert n == m
        return mat.flatten()[:-1].view(n - 1, n + 1)[:, 1:].flatten()

    def forward(self, x):
        N, C = x.shape
        if N == 1:
            return 0.0

        x = x - x.mean(dim=0, keepdim=True)
        x = x / torch.sqrt(self.eps + x.var(dim=0, keepdim=True))

        corr_mat = torch.matmul(x.t(), x)

        loss = (self._off_diagonal(corr_mat).pow(2)).mean()
        loss = loss / N

        return loss



eps = 1e-7

class SCELoss(torch.nn.Module):
    def __init__(self, alpha, beta, num_classes=10):
        super(SCELoss, self).__init__()
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.alpha = alpha
        self.beta = beta
        self.num_classes = num_classes
        self.cross_entropy = torch.nn.CrossEntropyLoss()

    def forward(self, pred, labels):
        # CCE
        ce = self.cross_entropy(pred, labels)

        # RCE
        pred = F.softmax(pred, dim=1)
        pred = torch.clamp(pred, min=1e-7, max=1.0)
        label_one_hot = torch.nn.functional.one_hot(labels, self.num_classes).float().to(self.device)
        label_one_hot = torch.clamp(label_one_hot, min=1e-4, max=1.0)
        rce = (-1*torch.sum(pred * torch.log(label_one_hot), dim=1))

        # Loss
        loss = self.alpha * ce + self.beta * rce.mean()
        return loss

import torch.nn.functional as F
from collections import defaultdict

class UnbiasedCrossEntropy(nn.Module):

    def __init__(self, true_labs, num_classes, reduction='mean', ignore_index=-100):
        super().__init__()
        self.reduction = reduction
        self.ignore_index = ignore_index
        self.true_labs = true_labs
        self.num_classes = num_classes  # 数据集的总类别数量


    def forward(self, inputs, targets):
        # 计算未出现的标签
        un_labels = [i for i in range(self.num_classes) if i not in self.true_labs]
        # 打印调试信息
        # print("True labels:", self.true_labs)
        # print("Unseen labels:", un_labels)

        outputs = torch.zeros_like(inputs)  # B, C (1+V+N), H, W
        den = torch.logsumexp(inputs, dim=1)  # B, H, W       den of softmax

        # 打印调试信息
        # print("Inputs before logsumexp:", inputs)
        # print("Denominator after logsumexp:", den)
        if 0 in un_labels:
            outputs[:, 0] = torch.logsumexp(inputs[:, un_labels], dim=1) - den  # B, H, W       p(O)
        else:
            outputs[:, 1] = torch.logsumexp(inputs[:, un_labels], dim=1) - den

        outputs[:, self.true_labs] = inputs[:, self.true_labs] - den.unsqueeze(dim=1)  # B, N, H, W    p(N_i)
        # 打印调试信息
        # print("Outputs:", outputs)
        labels = targets.clone()  # B, H, W
        # 打印调试信息
        # print("Targets:", labels)
        loss = F.nll_loss(outputs, labels, ignore_index=self.ignore_index, reduction=self.reduction)

        return loss


class KL_distill_loss(nn.KLDivLoss):

    def __init__(self, size_average=None, reduce=None, reduction='mean', log_target=True):
        super().__init__(size_average, reduce, reduction, log_target)

    def forward(self, inputs, targets):
        inputs = F.log_softmax(inputs, 1)
        targets = F.log_softmax(targets, 1)

        return super().forward(inputs, targets)


def L2_penalty(model, model_cache, omega=defaultdict(lambda: 1)):
    loss = 0
    params = {n: p.data.cuda() for n, p in model_cache.state_dict().items() if p.requires_grad}
    for n, p in model.state_dict().items():
        if p.requires_grad:
            _loss = omega[n] * (p - params[n]) ** 2
            loss += _loss.sum()
    return loss


def FeSA_loss(old_stats, new_stats):
    # forcing mean and variance to match between two distributions
    # other ways might work better, i.g. KL divergence
    r_feature = 0.
    for old, new in zip(old_stats, new_stats):
        # print(new.stats['var'].requires_grad)
        r_feature += torch.norm(old['var'] - new[0], 2) + \
                     torch.norm(old['mean'] - new[1], 2)

    return r_feature
class SupConLoss(nn.Module):
    def __init__(self):
        super(SupConLoss, self).__init__()

    def forward(self, features, labels, center):
        # 确保所有张量在同一设备上
        device = features.device
        center = [c.to(device) for c in center]  # 保证 center 也在同一设备上

        # 将中心张量堆叠并进行归一化
        center = torch.stack(center, dim=1)  # [feature_dim, num_classes]
        center = F.normalize(center, p=2, dim=0)  # L2 归一化 [feature_dim, num_classes]

        batch_size = features.shape[0]
        l_sc = 0.0

        # 遍历每个样本计算对比损失
        for i in range(batch_size):
            current_label = labels[i].item()  # 当前样本的标签
            current_feature = features[i]  # 当前样本的特征
            current_center = center[:, current_label]  # 取出当前类别的类中心

            # 计算分子部分
            numerator = torch.exp(torch.dot(current_feature, current_center))

            # 计算分母部分，对所有类中心进行操作
            denominator = torch.exp(torch.mm(current_feature.view(1, -1), center)).sum()

            # 计算损失并累加
            l_sc += -torch.log(numerator / denominator)

        # 计算平均损失
        l_sc = l_sc / batch_size

        return l_sc
class SupConLoss_new(nn.Module):
    def __init__(self, temperature=0.07):
        super(SupConLoss_new, self).__init__()
        self.temperature = temperature

    def forward(self, features, labels, center):
        # 确保特征和中心在相同的设备上
        device = features.device
        center = torch.stack([c.to(device) for c in center], dim=1)  # [feature_dim, num_classes]

        # L2 归一化
        features = F.normalize(features, p=2, dim=1)  # [batch_size, feature_dim]
        center = F.normalize(center, p=2, dim=0)  # [feature_dim, num_classes]

        # 获取每个样本的对应类中心
        batch_centers = center[:, labels].T  # [batch_size, feature_dim]

        # 计算每个样本和其类中心的相似性（分子）
        numerator = torch.exp((features * batch_centers).sum(dim=1) / self.temperature)  # [batch_size]

        # 计算每个样本和所有类中心的相似性（分母）
        logits = torch.mm(features, center) / self.temperature  # [batch_size, num_classes]
        denominator = torch.exp(logits).sum(dim=1)  # [batch_size]

        # 计算对比损失并取平均
        l_sc = -torch.log(numerator / denominator).mean()

        return l_sc
class DistillationLoss(nn.Module):
    def __init__(self, temperature=3.0, alpha=0.5):
        super(DistillationLoss, self).__init__()
        self.temperature = temperature
        self.alpha = alpha
        self.kl_loss = nn.KLDivLoss(reduction='batchmean')

    def forward(self, student_outputs, teacher_outputs, labels):
        # 将学生和教师输出通过 softmax 温度缩放
        student_probs = F.log_softmax(student_outputs / self.temperature, dim=1)
        teacher_probs = F.softmax(teacher_outputs / self.temperature, dim=1)

        # 计算蒸馏损失
        distillation_loss = self.kl_loss(student_probs, teacher_probs) * (self.temperature ** 2)

        # 交叉熵损失
        ce_loss = F.cross_entropy(student_outputs, labels)

        # 合并损失
        loss = self.alpha * ce_loss + (1 - self.alpha) * distillation_loss
        return loss
# class DistillationLoss(nn.Module):
#         def __init__(self, alpha=0.5, num_classes=10, epsilon=0.1):
#             """
#             Args:
#                 alpha (float): 交叉熵损失与蒸馏损失的加权系数。
#                 num_classes (int): 数据集的类别数。
#                 epsilon (float): 标签平滑系数。
#             """
#             super(DistillationLoss, self).__init__()
#             self.alpha = alpha
#             self.num_classes = num_classes
#             self.epsilon = epsilon

#         def z_score(self, logits):
#             """对 logits 进行标准化 (Z 分数标准化)"""
#             mean = logits.mean(dim=-1, keepdim=True)
#             stdv = logits.std(dim=-1, keepdim=True)
#             return (logits - mean) / (1e-7 + stdv)

#         def compute_temperature(self, logits):
#             """根据 logits 的加权标准差动态计算温度"""
#             probs = F.softmax(logits, dim=1)
#             mean = (logits * probs).sum(dim=1, keepdim=True)
#             variance = (probs * (logits - mean) ** 2).sum(dim=1, keepdim=True)
#             return torch.sqrt(variance + 1e-7)  # 避免数值问题

#         def forward(self, student_outputs, teacher_outputs, labels):
#             # 对 logit 进行标准化 (Z 分数)
#             student_outputs = self.z_score(student_outputs)
#             teacher_outputs = self.z_score(teacher_outputs)

#             # 动态计算温度
#             temperature = self.compute_temperature(teacher_outputs)

#             # 计算蒸馏损失
#             student_probs = F.log_softmax(student_outputs / temperature, dim=1)
#             teacher_probs = F.softmax(teacher_outputs / temperature, dim=1)
#             distillation_loss = F.kl_div(student_probs, teacher_probs, reduction="batchmean") * (temperature ** 2).mean()

#             # 标签平滑的交叉熵损失
#             log_probs = F.log_softmax(student_outputs, dim=1)
#             targets = torch.zeros_like(log_probs).scatter_(1, labels.unsqueeze(1), 1)
#             targets = (1 - self.epsilon) * targets + self.epsilon / self.num_classes
#             ce_loss = (-targets * log_probs).sum(dim=1).mean()

#             # 合并损失
#             loss = self.alpha * ce_loss + (1 - self.alpha) * distillation_loss
#             return loss