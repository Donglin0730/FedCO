# *************************************************************************
# This file may have been modified by Bytedance Inc. (“Bytedance Inc.'s Mo-
# difications”). All Bytedance Inc.'s Modifications are Copyright (2023) B-
# ytedance Inc..
# *************************************************************************

# Code ported from https://github.com/davda54/sam/blob/main/sam.py

# apply Sharpness-Aware-Minimization in local training
import os
from argparse import ArgumentParser

import copy
import torch.nn.functional as F
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
# from pyswarm import pso

from .fedavg import FedAvg

import sys
sys.path.insert(0, '../')
from utils import compute_accuracy
from loss import FedDecorrLoss, FeSA_loss, UnbiasedCrossEntropy
from torch.nn.modules.batchnorm import _BatchNorm
class Fed(FedAvg):

    def __init__(self, args, appr_args, logger, party_list_rounds,
                party2nets, global_net,
                party2loaders, global_train_dl, test_dl):
        super(Fed, self).__init__(args, appr_args, logger, party_list_rounds,
                party2nets, global_net,
                party2loaders, global_train_dl, test_dl)


    # function that processing the special arguments of current method
    @staticmethod
    def extra_parser(extra_args):
        parser = ArgumentParser()
        # sam arguments
        parser.add_argument('--calibration_temp', type=float, default=0.1, help='calibration temperature')
        return parser.parse_args(extra_args)

    def run_fed(self):
        for comm_round in range(self.args.n_comm_round):
            self.logger.info("in comm round:" + str(comm_round))

            # do local training on each party
            nets_this_round = self.local_training(comm_round)
            consistencies=self.compute_consistencies(nets_this_round)           # compute uncertainties for each client
            # uncertainties = self.compute_uncertainties(nets_this_round)

            # conduct global aggregation
            self.global_aggregation(nets_this_round, consistencies)

            print(f"Before Aggregation: nets_this_round={nets_this_round}")
            self.logger.info("Before Aggregation: consistencies:" + str(consistencies))




            print(f"After Aggregation: Global Model State Dict={self.global_net.state_dict()}")

            # compute acc
            self.global_net.cuda()
            train_acc, train_loss = compute_accuracy(self.global_net, self.global_train_dl)
            test_acc, test_loss = compute_accuracy(self.global_net, self.test_dl)
            self.global_net.to('cpu')

            # logging numbers
            self.logger.info('>> Global Model Train accuracy: %f' % train_acc)
            self.logger.info('>> Global Model Test accuracy: %f' % test_acc)
            self.logger.info('>> Global Model Train loss: %f' % train_loss)

            if (comm_round + 1) % self.args.print_interval == 0:
                print('round: ', str(comm_round))
                print('>> Global Model Train accuracy: %f' % train_acc)
                print('>> Global Model Test accuracy: %f' % test_acc)
                print('>> Global Model Train loss: %f' % train_loss)

            if (comm_round+1) % self.args.save_interval == 0:
                torch.save(self.global_net.state_dict(),
                    os.path.join(self.args.ckptdir, self.args.approach, 'globalmodel_'+self.args.log_file_name+'.pth'))
                torch.save(self.party2nets[0].state_dict(),
                    os.path.join(self.args.ckptdir, self.args.approach, 'localmodel0_'+self.args.log_file_name+'.pth'))

            # previous_round_models = {party_id: net.copy() for party_id, net in nets_this_round.items()}

    def _local_training(self, party_id):
        net = self.party2nets[party_id]
        net.train()
        net.cuda()

        train_dataloader = self.party2loaders[party_id]
        test_dataloader = self.test_dl
        n_class = net.classifier.out_features
        class2data = torch.zeros(n_class)
        ds = train_dataloader.dataset
        uniq_val, uniq_count = np.unique(ds.target, return_counts=True)
        true_labs = uniq_val.tolist()
        # true_labs = [0, 2,1, 3,4, 5, 6, 7, 8,9]
        for i, c in enumerate(uniq_val.tolist()):
            class2data[c] = uniq_count[i]


        self.logger.info('Training network %s' % str(party_id))
        self.logger.info('n_training: %d' % len(train_dataloader))
        self.logger.info('n_test: %d' % len(test_dataloader))

        train_acc, _ = compute_accuracy(net, train_dataloader)
        test_acc, _ = compute_accuracy(net, test_dataloader)

        self.logger.info('>> Pre-Training Training accuracy: {}'.format(train_acc))
        self.logger.info('>> Pre-Training Test accuracy: {}'.format(test_acc))


        optimizer = optim.SGD(filter(lambda p: p.requires_grad, net.parameters()),
                              lr=self.args.lr, momentum=self.args.rho, weight_decay=self.args.weight_decay)

        # Store old stats
        old_stats = []
        for name, module in net.named_modules():
            if isinstance(module, nn.BatchNorm2d):
                old_stats.append({'mean': module.running_mean.clone(), 'var': module.running_var.clone()})
        if self.args.dataset in {'mnist', 'cifar10', 'svhn'}:
            # true_labs = list(range(10))
            num_classes=10
        elif self.args.dataset == 'cifar100':
            # true_labs = list(range(100))
            num_classes = 100
        elif self.args.dataset == 'tinyimagenet':
            # true_labs = list(range(200))
            num_classes = 200
        else:
            raise ValueError('Unsupported dataset: {}'.format(self.args.dataset))
        # true_labs = list(true_labs)
        n_step = 0
        criterion = UnbiasedCrossEntropy(true_labs=true_labs,num_classes=num_classes)
        # criterion = nn.CrossEntropyLoss()
        initial_loss = None  # 初始化初始损失变量
        for epoch in range(self.args.epochs):
            epoch_loss_collector = []
            for batch_idx, (x, target) in enumerate(train_dataloader):
                x, target = x.cuda(), target.cuda()
                target = target.long()
                optimizer.zero_grad()
                out = net(x)
                # calibrate logit
                # out -= self.appr_args.calibration_temp * class2data ** (-0.25)
                loss = criterion(out, target)
                # Compute FeSA loss
                new_stats = []
                for name, module in net.named_modules():
                    if isinstance(module, nn.BatchNorm2d):
                        new_stats.append((module.running_var, module.running_mean))

                feature_loss = 0.001 * FeSA_loss(old_stats, new_stats)
                loss += feature_loss
                loss.backward()
                torch.nn.utils.clip_grad_norm_(parameters=net.parameters(), max_norm=10)
                optimizer.step()
                n_step += 1
                # 记录初始损失
                if initial_loss is None:
                    initial_loss = loss.item()
                epoch_loss_collector.append(loss.item())
            epoch_loss = sum(epoch_loss_collector) / len(epoch_loss_collector)

            self.logger.info('Epoch: %d Loss: %f' % (epoch, epoch_loss))

        train_acc, _ = compute_accuracy(net, train_dataloader)
        test_acc, _ = compute_accuracy(net, test_dataloader)
        self.logger.info('>> Training accuracy: %f' % train_acc)
        self.logger.info('>> Test accuracy: %f' % test_acc)
        net.to('cpu')


        # a_i = (n_step - self.args.rho * (1 - pow(self.args.rho, n_step)) / (1 - self.args.rho)) / (1 - self.args.rho)
        #
        # net_para = net.state_dict()
        # for key in net_para:
        #     net_para[key] = global_w[key].to(net_para[key].device) + torch.true_divide(
        #         net_para[key].to('cpu') - global_w[key].to('cpu'), a_i)
        # net.load_state_dict(net_para)

    def local_training(self, comm_round):
        # conduct local training on all selected clients
        party_list_this_round = self.party_list_rounds[comm_round]
        nets_this_round = {k: self.party2nets[k] for k in party_list_this_round}

        # send global model to all selected clients
        global_w = self.global_net.state_dict()
        for net in nets_this_round.values():
            net.load_state_dict(global_w)

        # enumerate all clients and train locally
        for party_id in nets_this_round:
            self._local_training(party_id)

        return nets_this_round

    # def compute_consistencies(self, nets_this_round):
    #
    #     consistencies = []
    #     device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    #     for net in nets_this_round.values():
    #         net.eval()
    #         net.to(device)
    #         test_dataloader = self.test_dl
    #         total_entropy = 0.0
    #         total_variance = 0.0
    #         num_samples = 0
    #         with torch.no_grad():
    #             for x, _ in test_dataloader:
    #                 x = x.to(device)
    #                 outputs = net(x)
    #                 probabilities = F.softmax(outputs, dim=1)
    #                 variances = torch.var(probabilities, dim=1)
    #                 total_variance += torch.sum(variances).item()
    #                 num_samples += len(x)
    #         average_variance = total_variance / num_samples
    #
    #         consistencies.append(average_variance)
    #     return  consistencies
    def compute_consistencies(self, nets_this_round):

        consistencies = []
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        for net in nets_this_round.values():
            net.eval()
            net.to(device)
            test_dataloader = self.test_dl

            # 初始化总熵、总方差和样本数
            total_entropy = 0.0
            total_variance = 0.0
            num_samples = 0

            # 初始化标签分布
            class_counts = torch.zeros(net.classifier.out_features).to(device)

            with torch.no_grad():
                for x, target in test_dataloader:
                    x = x.to(device)
                    target = target.to(device)

                    # 计算标签的频率
                    for label in target:
                        class_counts[label] += 1

                    # 计算方差和一致性
                    outputs = net(x)
                    probabilities = F.softmax(outputs, dim=1)
                    variances = torch.var(probabilities, dim=1)
                    total_variance += torch.sum(variances).item()
                    num_samples += len(x)

            # 计算标签熵
            class_probabilities = class_counts / class_counts.sum()
            label_entropy = -torch.sum(class_probabilities * torch.log(class_probabilities + 1e-10)).item()

            # 根据标签熵调整平均方差
            average_variance = total_variance / num_samples
            adjusted_variance = average_variance / (1 + label_entropy)

            consistencies.append(adjusted_variance)

        return consistencies

    # def global_aggregation(self, nets_this_round, consistencies):
    #     epsilon = 1e-10
    #     # Normalize uncertainties
    #     total_consistencies = sum(consistencies)
    #     if total_consistencies == 0:
    #         normalized_consistencies = [1.0 / len(consistencies)] * len(consistencies)
    #     else:
    #         normalized_consistencies = [unc / total_consistencies for unc in consistencies]
    #
    #     # Calculate optimization coefficients
    #     optimization_coefficients = [1 / (consistencies + epsilon) for consistencies in normalized_consistencies]
    #
    #     # Calculate weighted data points
    #     weighted_data_points = [opt_coef * len(self.party2loaders[r].dataset) for opt_coef, r in
    #                             zip(optimization_coefficients, nets_this_round)]
    #     total_weighted_data_points = sum(weighted_data_points)
    #
    #     # Check for valid values
    #     if total_weighted_data_points == 0:
    #         raise ValueError("Total weighted data points cannot be zero.")
    #
    #     # Calculate federated averaging frequencies
    #     fed_avg_freqs = [wdp / total_weighted_data_points for wdp in weighted_data_points]
    #
    #     # Ensure frequencies sum to 1
    #     if not (0.999 < sum(fed_avg_freqs) < 1.001):
    #         self.logger.warning(f"fed_avg_freqs does not sum to 1: {sum(fed_avg_freqs)}")
    #
    #     # Aggregate global weights
    #     device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    #     global_w_init = {k: v.to(device) for k, v in self.global_net.state_dict().items()}
    #     global_w = {k: v.to(device) for k, v in self.global_net.state_dict().items()}
    #
    #     for net_id, (net, freq) in enumerate(zip(nets_this_round.values(), fed_avg_freqs)):
    #         net_para = {k: v.to(device) for k, v in net.state_dict().items()}
    #         if net_id == 0:
    #             for key in net_para:
    #                 global_w[key] = net_para[key] * freq
    #         else:
    #             for key in net_para:
    #                 global_w[key] += net_para[key] * freq
    #     # self.global_net.load_state_dict(global_w)
    #     tau_eff = sum([fed_avg_freqs[r] for r in nets_this_round])
    #     for key in global_w:
    #         global_w[key] = global_w_init[key] + tau_eff * (global_w[key] - global_w_init[key])
    #
    #     self.global_net.load_state_dict({k: v.cpu() for k, v in global_w.items()})

    def global_aggregation(self, nets_this_round, uncertainties):
        # Calculate inverse uncertainty weights
        weights = [1 / uncertainty for uncertainty in uncertainties]
        total_weight = sum(weights)
        normalized_weights = [weight / total_weight for weight in weights]

        # Initialize global model weights
        global_w = self.global_net.state_dict()

        for net_id, (party_id, net) in enumerate(nets_this_round.items()):
            net_para = net.state_dict()
            weight = normalized_weights[net_id]

            if net_id == 0:
                for key in net_para:
                    global_w[key] = net_para[key] * weight
            else:
                for key in net_para:
                    global_w[key] += net_para[key] * weight

        self.global_net.load_state_dict(global_w)

    # def global_aggregation(self, nets_this_round, consistencies):
    #     epsilon = 1e-10
    #     # Normalize uncertainties
    #     total_uncertainty = sum(consistencies)
    #     if total_uncertainty == 0:
    #         normalized_uncertainties = [1.0 / len(consistencies)] * len(consistencies)
    #     else:
    #         normalized_uncertainties = [unc / total_uncertainty for unc in consistencies]
    #
    #     # Calculate optimization coefficients
    #     optimization_coefficients = [1 / (uncertainty + epsilon) for uncertainty in normalized_uncertainties]
    #
    #     # Calculate weighted data points
    #     weighted_data_points = [opt_coef * len(self.party2loaders[r].dataset) for opt_coef, r in
    #                             zip(optimization_coefficients, nets_this_round)]
    #     total_weighted_data_points = sum(weighted_data_points)
    #
    #     # Check for valid values
    #     if total_weighted_data_points == 0:
    #         raise ValueError("Total weighted data points cannot be zero.")
    #
    #     # Calculate federated averaging frequencies
    #     fed_avg_freqs = [wdp / total_weighted_data_points for wdp in weighted_data_points]
    #
    #     # Ensure frequencies sum to 1
    #     if not (0.999 < sum(fed_avg_freqs) < 1.001):
    #         self.logger.warning(f"fed_avg_freqs does not sum to 1: {sum(fed_avg_freqs)}")
    #
    #     # Aggregate global weights
    #     global_w_init = copy.deepcopy(self.global_net.state_dict())
    #     global_w = self.global_net.state_dict()
    #     for net_id, (net, freq) in enumerate(zip(nets_this_round.values(), fed_avg_freqs)):
    #         net_para = net.state_dict()
    #         if net_id == 0:
    #             for key in net_para:
    #                 global_w[key] = net_para[key] * freq
    #         else:
    #             for key in net_para:
    #                 global_w[key] += net_para[key] * freq
    #     tau_eff = sum([fed_avg_freqs[r]  for r in nets_this_round])
    #     for key in global_w:
    #         global_w[key] = global_w_init[key] + tau_eff * (global_w[key] - global_w_init[key])
    #
    #     self.global_net.load_state_dict(global_w)

    # def compute_uncertainties(self, nets_this_round):
    #     uncertainties = []
    #     device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    #     for net in nets_this_round.values():
    #         net.eval()
    #         net.to(device)
    #         test_dataloader = self.test_dl
    #         total_entropy = 0.0
    #         num_samples = 0
    #         with torch.no_grad():
    #             for x, _ in test_dataloader:
    #                 x = x.to(device)
    #                 outputs = net(x)
    #                 probabilities = F.softmax(outputs, dim=1)
    #                 entropies = -torch.sum(probabilities * torch.log(probabilities + 1e-10), dim=1)
    #                 total_entropy += torch.sum(entropies).item()
    #                 num_samples += len(x)
    #         average_entropy = total_entropy / num_samples
    #         # Ensure the average entropy is non-negative
    #         average_entropy = max(average_entropy, 0)
    #         uncertainties.append(average_entropy)
    #     return uncertainties

# def disable_running_stats(model):
#     def _disable(module):
#         if isinstance(module, _BatchNorm):
#             module.backup_momentum = module.momentum
#             module.momentum = 0
#
#     model.apply(_disable)
#
# def enable_running_stats(model):
#     def _enable(module):
#         if isinstance(module, _BatchNorm) and hasattr(module, "backup_momentum"):
#             module.momentum = module.backup_momentum
#
#     model.apply(_enable)

# class SAM(torch.optim.Optimizer):
#
#     def __init__(self, params, base_optimizer, rho=0.05, adaptive=False, **kwargs):
#         assert rho >= 0.0, f"Invalid rho, should be non-negative: {rho}"
#
#         defaults = dict(rho=rho, adaptive=adaptive, **kwargs)
#         super(SAM, self).__init__(params, defaults)
#
#         self.base_optimizer = base_optimizer(self.param_groups, **kwargs)
#         self.param_groups = self.base_optimizer.param_groups
#         self.gamma=0.1
#         self.beta=0.01
#     @torch.no_grad()
#     def first_step(self, zero_grad=False):
#         grad_norm = self._grad_norm()
#         for group in self.param_groups:
#             scale = group["rho"] / (grad_norm + 1e-12)
#
#             for p in group["params"]:
#                 p.requires_grad = True
#                 if p.grad is None: continue
#                 self.state[p]["original"] = p.data.clone()
#                 # original SAM
#                 # e_w = p.grad * scale.to(p)
#                 e_w = (torch.pow(p, 2) if group["adaptive"] else 1.0) * p.grad * scale.to(p)
#                 p.add_(e_w)  # climb to the local maximum "w + e(w)"
#                 self.state[p]["e_w"] = e_w
#
#         if zero_grad: self.zero_grad()
#
#     @torch.no_grad()
#     def second_step(self, zero_grad=False):
#         for group in self.param_groups:
#             for p in group["params"]:
#                 if p.grad is None: continue
#                 self.state[p]["worst"] = p.grad.clone()
#                 p.sub_(self.state[p]["e_w"] * 2.0)  # get back to "w" from "w + e(w)"
#
#         # self.base_optimizer.step()  # do the actual "sharpness-aware" update
#
#         if zero_grad: self.zero_grad()
#
#     @torch.no_grad()
#     def third_step(self, zero_grad=False):
#         for group in self.param_groups:
#             for p in group["params"]:
#                 if p.grad is None: continue
#                 self.state[p]["best"] = p.grad.clone()
#                 p.add_(self.state[p]["e_w"])
#
#         for group in self.param_groups:
#             for p in group["params"]:
#                 if p.grad is None: continue
#                 p.grad = self.state[p]["worst"] + self.gamma * (
#                         self.state[p]["worst"] + self.state[p]["best"] - 2 * self.state[p][
#                     "original"]) + self.beta * ((self.state[p]["worst"] - self.state[p]["best"]))
#
#         self.base_optimizer.step()
#         if zero_grad: self.zero_grad()
#
#     @torch.no_grad()
#     def step(self, closure=None):
#         raise NotImplementedError(
#             "SAM doesn't work like the other optimizers, you should first call `first_step` and the `second_step`; see the documentation for more info.")
#
#     def _grad_norm(self):
#         shared_device = self.param_groups[0]["params"][0].device  # put everything on the same device, in case of model parallelism
#         norm = torch.norm(
#                     torch.stack([
#                         ((torch.abs(p) if group["adaptive"] else 1.0) * p.grad).norm(p=2).to(shared_device)
#                         for group in self.param_groups for p in group["params"]
#                         if p.grad is not None
#                     ]),
#                     p=2
#                )
#         return norm
#
#     def load_state_dict(self, state_dict):
#         super().load_state_dict(state_dict)
#         self.base_optimizer.param_groups = self.param_groups
#
