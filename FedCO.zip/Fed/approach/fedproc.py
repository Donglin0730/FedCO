import copy
import os
from argparse import ArgumentParser

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

import sys
sys.path.insert(0, '../')
from utils import compute_accuracy
from loss import FedDecorrLoss, SupConLoss, SupConLoss_new


class FedProc:

    def __init__(self, args, appr_args, logger, party_list_rounds,
                party2nets, global_net,
                party2loaders, global_train_dl, test_dl):
        self.args = args
        self.appr_args = appr_args
        self.logger = logger
        self.party_list_rounds = party_list_rounds
        self.party2nets = party2nets
        self.global_net = global_net
        self.party2loaders = party2loaders
        self.global_train_dl = global_train_dl
        self.test_dl = test_dl

        self.flag = 0

    # function that processing the special arguments of current method
    @staticmethod
    def extra_parser(extra_args):
        parser = ArgumentParser()
        # feddecorr arguments
        parser.add_argument('--feddecorr', action='store_true',
                            help='whether to use FedDecorr')
        parser.add_argument('--feddecorr_coef', type=float, default=0.1,
                            help='coefficient of the FedDecorr loss')
        return parser.parse_args(extra_args)


    # function that executing the federated training
    def run_fed(self):
        for comm_round in range(self.args.n_comm_round):
            self.logger.info("in comm round:" + str(comm_round))
            # 获取全局类别中心,设置第0轮的全局原型
            nets_this_round = self.party2nets
            if self.flag == 0:
                global_class_center_old = None
                global_class_center = self.get_global_class_center(global_class_center_old,self.args.n_parties,nets_this_round,
                                                               logger=self.logger)
                self.flag = 1



            # 本地训练
            nets_this_round = self.local_training(comm_round,global_class_center)

            # 更新全局类别中心
            global_class_center_old = copy.deepcopy(global_class_center)
            global_class_center = self.get_global_class_center(global_class_center_old,self.args.n_parties,nets_this_round,
                                                               logger=self.logger)

            # do local training on each party


            # conduct global aggregation
            self.global_aggregation(nets_this_round)

            # compute acc
            self.global_net.cuda()
            train_acc, train_loss = compute_accuracy(self.global_net, self.global_train_dl)
            test_acc, test_loss = compute_accuracy(self.global_net, self.test_dl)
            self.global_net.to('cpu')

            # logging numbers
            self.logger.info('>> Global Model Train accuracy: %f' % train_acc)
            self.logger.info('>> Global Model Test accuracy: %f' % test_acc)
            self.logger.info('>> Global Model Train loss: %f' % train_loss)

            if (comm_round + 1) % self.args.print_interval == 0:
                print('round: ', str(comm_round))
                print('>> Global Model Train accuracy: %f' % train_acc)
                print('>> Global Model Test accuracy: %f' % test_acc)
                print('>> Global Model Train loss: %f' % train_loss)

            if (comm_round+1) % self.args.save_interval == 0:
                torch.save(self.global_net.state_dict(),
                    os.path.join(self.args.ckptdir, self.args.approach, 'globalmodel_'+self.args.log_file_name+'.pth'))
                torch.save(self.party2nets[0].state_dict(),
                    os.path.join(self.args.ckptdir, self.args.approach, 'localmodel0_'+self.args.log_file_name+'.pth'))


    def global_aggregation(self, nets_this_round):
        total_data_points = sum([len(self.party2loaders[r].dataset) for r in nets_this_round])
        fed_avg_freqs = [len(self.party2loaders[r].dataset) / total_data_points for r in nets_this_round]

        global_w = self.global_net.state_dict()
        for net_id, net in enumerate(nets_this_round.values()):
            net_para = net.state_dict()
            if net_id == 0:
                for key in net_para:
                    global_w[key] = net_para[key] * fed_avg_freqs[net_id]
            else:
                for key in net_para:
                    global_w[key] += net_para[key] * fed_avg_freqs[net_id]
        self.global_net.load_state_dict(global_w)


    def local_training(self, comm_round,global_class_center):
        # conduct local training on all selected clients
        party_list_this_round = self.party_list_rounds[comm_round]
        nets_this_round = {k: self.party2nets[k] for k in party_list_this_round}

        # send global model to all selected clients
        global_w = self.global_net.state_dict()
        for net in nets_this_round.values():
            net.load_state_dict(global_w)

        # enumerate all clients and train locally
        for party_id in nets_this_round:
            self._local_training(party_id,global_class_center)

        return nets_this_round


    def _local_training(self, party_id,global_class_center):
        net = self.party2nets[party_id]
        net.train()
        net.cuda()

        train_dataloader = self.party2loaders[party_id]
        test_dataloader = self.test_dl

        self.logger.info('Training network %s' % str(party_id))
        self.logger.info('n_training: %d' % len(train_dataloader))
        self.logger.info('n_test: %d' % len(test_dataloader))

        train_acc, _ = compute_accuracy(net, train_dataloader)
        test_acc, _ = compute_accuracy(net, test_dataloader)

        self.logger.info('>> Pre-Training Training accuracy: {}'.format(train_acc))
        self.logger.info('>> Pre-Training Test accuracy: {}'.format(test_acc))

        optimizer = optim.SGD(filter(lambda p: p.requires_grad, net.parameters()),
                              lr=self.args.lr, momentum=self.args.rho, weight_decay=self.args.weight_decay)
        criterion = nn.CrossEntropyLoss()
        feddecorr = FedDecorrLoss()
        criterion_extra = SupConLoss_new()

        for epoch in range(self.args.epochs):
            epoch_loss_collector = []
            for batch_idx, (x, target) in enumerate(train_dataloader):
                x, target = x.cuda(), target.cuda()
                target = target.long()
                optimizer.zero_grad()
                out, features = net(x, return_features=True)

                CEloss = criterion(out, target)
                SCloss = criterion_extra(features=features, labels=target, center=global_class_center)
                loss= 0.5*CEloss+0.5*SCloss
                loss.backward()
                optimizer.step()

                epoch_loss_collector.append(loss.item())

            epoch_loss = sum(epoch_loss_collector) / len(epoch_loss_collector)
            self.logger.info('Epoch: %d Loss: %f' % (epoch, epoch_loss))

        train_acc, _ = compute_accuracy(net, train_dataloader)
        test_acc, _ = compute_accuracy(net, test_dataloader)
        self.logger.info('>> Training accuracy: %f' % train_acc)
        self.logger.info('>> Test accuracy: %f' % test_acc)
        net.to('cpu')

    def get_global_class_center(self, global_class_center_old, n_parties, nets_this_round, logger):
        local_class_center = []
        clsnum = next(iter(nets_this_round.values())).classifier.out_features
        class_count = np.zeros((n_parties, clsnum))

        for party_id, net in nets_this_round.items():
            net.cuda()
            train_dataloader = self.party2loaders[party_id]
            class_feature = {}
            with torch.no_grad():
                for x, target in train_dataloader:
                    x, target = x.cuda(), target.cuda()
                    out, features = net(x, return_features=True)  # 返回两个值

                    for label in torch.unique(target):
                        index = torch.eq(target, label)
                        feature = features[index]

                        lab = str(label.cpu().numpy())
                        if lab not in class_feature:
                            class_feature[lab] = torch.sum(feature, 0)
                            class_count[party_id][label] = feature.shape[0]
                        else:
                            class_feature[lab] += torch.sum(feature, 0)
                            class_count[party_id][label] += feature.shape[0]
            net.to('cpu')
            local_class_center.append(class_feature)

        # 聚合全局类别中心
        global_center = [[] for _ in range(clsnum)]
        inittype = torch.zeros_like(next(iter(local_class_center[0].values())))
        for cls in range(clsnum):
            for local_feature in local_class_center:
                if str(cls) in local_feature:
                    if global_center[cls] == []:
                        global_center[cls] = local_feature[str(cls)]
                    else:
                        global_center[cls] += local_feature[str(cls)]

            if global_center[cls] == []:
                global_center[cls] = global_class_center_old[cls] if global_class_center_old else inittype
            else:
                global_center[cls] /= sum(class_count[:, cls])

        logger.info("Global class center updated.")
        return global_center
